﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Atributos
    {
        public int fuerza { get; set; }
        public int agilidad { get; set; }
        public int inteligencia { get; set; }
        public int resistencia { get; set; }
        public int impresion { get; set; }

        public Atributos(int fuerza, int agilidad, int inteligencia, int resistencia, int impresion)
        {
            this.fuerza = fuerza;
            this.agilidad = agilidad;
            this.inteligencia = inteligencia;
            this.resistencia = resistencia;
            this.impresion = impresion;
        }
    }
}

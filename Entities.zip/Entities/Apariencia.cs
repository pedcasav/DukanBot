﻿using SFML.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Apariencia
    {
        public int cabello { get; set; }
        public Color colorCabello { get; set; }
        public Color colorPiel { get; set; }
        public int camiseta { get; set; }
        public int pantalon { get; set; }
        public int zapatos { get; set; }
        public Apariencia(int cabello, Color colorCabello, Color colorPiel, int camiseta, int pantalon, int zapatos)
        {
            this.cabello = cabello;
            this.colorCabello = colorCabello;
            this.colorPiel = colorPiel;
            this.camiseta = camiseta;
            this.pantalon = pantalon;
            this.zapatos = zapatos;
        } 
    }
}

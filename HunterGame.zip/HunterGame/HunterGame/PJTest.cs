﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace HunterGame
{
    class PJTest : AnimatedCharacter
    {
        public PJTest() : base(Application.StartupPath + @"\thelegal.png")
        {
        }
    }
}

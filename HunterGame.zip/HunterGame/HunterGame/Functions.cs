﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HunterGame.Entidades;

namespace HunterGame
{
    class Functions
    {
        public static int lookPJ(string username)
        {
            return Global.Personajes.FindIndex(m => m.nickname == username);
        }
    }
}

﻿using SFML.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HunterGame
{
    class Map
    {
        public string url { get; set; }
        //image size
        Sprite[,] tiles;
        int mapWidth = 100;
        int mapHeight = 100;
        Sprite sprite;
        public Map(string url)
        {
            try
            {
                this.url = url;
                //source image size
                int tilemapWidth = 21;
                int tilemapHeight = 23;
                int tileSize = 32;
                //Load Source
                Texture texture = new Texture(Application.StartupPath + @"\map\"+ this.url +".png");
                sprite = new Sprite(texture, new IntRect(0, 0, (int)texture.Size.X, (int)texture.Size.Y));
            }
            catch (Exception ex)
            {
            }


        }
        public void Draw(RenderWindow window)
        {
            try
            {
                //for (int y = 0; y < mapHeight; y++)
                //{
                //    for (int x = 0; x < mapWidth; x++)
                //    {
                //        window.Draw(tiles[x, y]);
                //    }
                //}
                
                window.Draw(sprite);
            }
            catch (Exception ex)
            {
            }
        }
    }
}

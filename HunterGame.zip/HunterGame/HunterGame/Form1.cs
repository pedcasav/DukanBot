﻿using System.Windows.Forms;
using SFML;
using SFML.Graphics;
using SFML.Window;
using System.IO;
using SFML.System;
using System;
using System.ComponentModel;
using System.Threading;

namespace HunterGame
{
    public partial class Form1 : Form
    {
        RenderWindow GameWindow;
        Texture textura;
        Thread MainThread;
        int x = 0, y = 0,row=0,column=0;
        bool isPressed = false; Keys pressedkey = 0;
        DateTime elapsedTime = DateTime.Now;
        public Form1()
        {
            InitializeComponent();
            textura = new Texture(Application.StartupPath + @"\thelegal.png");
            

            //Texture playertxr = new Texture(Application.StartupPath + @"\thelegal.png");
            //Sprite playerspr = new Sprite(playertxr);
            //playerspr.Position = new Vector2f(1, 1);
            //GameWindow.Clear(Color.Black);
            //// TODO: Insert Draw Code Here
            //GameWindow.Draw(playerspr);
        }
        void GameLoop()
        {
            TimeSpan delta = DateTime.Now - elapsedTime;
            MethodInvoker mi = delegate () {

                do
                {
                    delta = DateTime.Now - elapsedTime;
                    if (delta.TotalMilliseconds >= 10000/60)
                    {

                        Render_Graphics();
                        elapsedTime = DateTime.Now;
                    }
                Application.DoEvents();

            }
            while (true);
            };
            this.Invoke(mi);
        }
        void Render_Graphics()
        {
            GameWindow.DispatchEvents();
            GameWindow.Clear(SFML.Graphics.Color.Black);
            DibujarTextura(textura, new Vector2f(x, y), (int)textura.Size.X/4, (int)textura.Size.Y / 4);
            GameWindow.Display();

        }
        void DibujarTextura(Texture Textura, Vector2f Posicion, int Ancho, int alto)
        {
            if (Textura == null) return;
            SFML.Graphics.Color colour = new SFML.Graphics.Color(255, 255, 255, 255);
            Sprite tmpSprite = new Sprite(Textura);
            tmpSprite.Position = Posicion;            
            tmpSprite.TextureRect = new IntRect(column* (int)textura.Size.X / 4, row * (int)textura.Size.Y / 4, Ancho, alto);
            //tmpSprite.Scale = new Vector2f(0, 0);
            //tmpSprite.Color = colour;
            GameWindow.Draw(tmpSprite);
    }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        
        private void Form1_Load(object sender, System.EventArgs e)
        {
            GameWindow = new RenderWindow(pcMain.Handle);
            MainThread = new Thread(GameLoop);
            MainThread.Start();
        }


        private void Form1_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (isPressed)
                isPressed = false;
        }

        private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (pressedkey == e.KeyCode) isPressed = false;
            if (isPressed) return;
            if (e.KeyCode == Keys.Down)
            {
                y = y + 1;
                row = 0;
                pressedkey = Keys.Down;
                isPressed=true;
            }
            else if (e.KeyCode == Keys.Up)
            {
                y = y - 1;
                row = 3;
                isPressed = true;
                pressedkey = Keys.Up;
            }
            else if (e.KeyCode == Keys.Left)
            {
                x = x - 1;
                row = 1;
                isPressed = true;
                pressedkey = Keys.Left;
            }
            else if (e.KeyCode == Keys.Right)
            {
                x = x + 1;
                row = 2;
                isPressed = true;
                pressedkey = Keys.Right;
            }
            ChangeFrame();
        }
        void ChangeFrame()
        {
            if (column != 3)
                column++;
            else column = 0;
        }
    }
}

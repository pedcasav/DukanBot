﻿using System.Windows.Forms;
using SFML;
using SFML.Graphics;
using SFML.Window;
using System.IO;
using SFML.System;
using System;
using System.ComponentModel;
using System.Threading;
using System.Collections.Generic;

using HunterGame.Entidades;
using HunterGame.Editores;
namespace HunterGame
{
    public partial class Form1 : Form
    {
        RenderWindow GameWindow;
        Texture textura;
        Thread MainThread;
        int x = 0, y = 0, row = 0, column = 0;
        bool isPressed = false; Keys pressedkey = 0;
        DateTime elapsedTime = DateTime.Now;
        public Form1()
        {
            InitializeComponent();
            textura = new Texture(Application.StartupPath + @"\thelegal.png");
            //Texture playertxr = new Texture(Application.StartupPath + @"\thelegal.png");
            //Sprite playerspr = new Sprite(playertxr);
            //playerspr.Position = new Vector2f(1, 1);
            //GameWindow.Clear(Color.Black);
            //// TODO: Insert Draw Code Here
            //GameWindow.Draw(playerspr);
        }
        private List<Mapa> CargarMapas()
        {
            List<Mapa> Mapas = new List<Mapa>();
            using (StreamReader sr = new StreamReader(Application.StartupPath + @"\map\Mapas.pca"))
            {
                string current = string.Empty;
                while ((current = sr.ReadLine()) != null)
                {
                    string[] line = current.Split(',');
                    Mapa temp = new Mapa(line[0], line[1]);
                    temp.sizex = int.Parse(line[2]);
                    temp.sizey = int.Parse(line[3]);
                    Mapas.Add(temp);
                }
                
            }
            foreach (Mapa Mapa in Mapas)
            {
                Mapa.atributos = new AtributosMapa[Mapa.sizex, Mapa.sizey];
                using (StreamReader sr = new StreamReader(Application.StartupPath + @"\map\" + Mapa.value + ".csv"))
                {
                    string line = string.Empty;
                    int i = 0;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] x = line.Split(',');

                        for (int j = 0; j < Mapa.sizey; j++)

                            Mapa.atributos[i, j] = getFromLine(x[j]);
                        i++;
                    }
                }
            }
            return Mapas;
        }
        AtributosMapa getFromLine(string line)
        {
            string[] arr = line.Split(';');
            return new AtributosMapa(int.Parse(arr[0]), arr[1], int.Parse(arr[2]), int.Parse(arr[3]), int.Parse(arr[4]), int.Parse(arr[5]));
        }
        void GameLoop()
        {
            

            Clock clock = new Clock();
            //test code
            SFML.Graphics.Text test = new SFML.Graphics.Text("", new SFML.Graphics.Font(@"C:\Windows\Fonts\arial.ttf"),18);
            

            //test code
            test.Position = new Vector2f(1, 1);
            Global.Mapas = CargarMapas();
            Personaje Personaje = new Personaje("Dukan", 1, 1, new Apariencia(1, Color.Red, Color.Red, 1, 1, 1), 1, 1, 1, 0, new List<Objeto>(), new Objeto[6], new Atributos(1,1,1,1,1),0, 0, 0, 100, 5);
            Global.Personajes.Add(Personaje);
            SFML.Graphics.View view = new SFML.Graphics.View(new Vector2f(0, 0), new Vector2f(this.Size.Width, this.Size.Height));

            MethodInvoker mi = delegate ()
            {

                do
                {
                    GameWindow.DispatchEvents();

                    float deltaTime = clock.Restart().AsSeconds();


                    
                    Personaje.Player.Update(deltaTime);
                    test.DisplayedString = string.Format("{0}, {1}", Personaje.Player.Xpos, Personaje.Player.Ypos);
                    eMain.Functions(Personaje.nickname);

                    view.Center = new Vector2f(Personaje.Player.Xpos, Personaje.Player.Ypos);
                    GameWindow.SetView(view);

                    
                    Global.Mapas[Personaje.Player.map].Map.Draw(GameWindow);
                    Personaje.Player.Draw(GameWindow);
                    GameWindow.Draw(test);

                    GameWindow.Display();
                    Application.DoEvents();

                }
                while (true);
            };
            this.Invoke(mi);
        }
        void Render_Graphics()
        {
            

        }
        void DibujarTextura(Texture Textura, Vector2f Posicion, int Ancho, int alto)
        {
            if (Textura == null) return;
            SFML.Graphics.Color colour = new SFML.Graphics.Color(255, 255, 255, 255);
            Sprite tmpSprite = new Sprite(Textura);
            tmpSprite.Position = Posicion;            
            tmpSprite.TextureRect = new IntRect(column* (int)textura.Size.X / 4, row * (int)textura.Size.Y / 4, Ancho, alto);
            //tmpSprite.Scale = new Vector2f(0, 0);
            //tmpSprite.Color = colour;
            GameWindow.Draw(tmpSprite);
    }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        
        private void Form1_Load(object sender, System.EventArgs e)
        {
            GameWindow = new RenderWindow(this.Handle);
            MainThread = new Thread(GameLoop);
            MainThread.Start();
        }


        private void Form1_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (column == 3) column = 0;
            else column = 2;
            if (isPressed)
                isPressed = false;
        }

        private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (pressedkey == e.KeyCode) isPressed = false;
            if (isPressed) return;
            
            if (e.KeyCode == Keys.Down)
            {
                y = y + 5;
                row = 0;
                pressedkey = Keys.Down;
                isPressed=true;
            }
            else if (e.KeyCode == Keys.Up)
            {
                y = y - 5;
                row = 3;
                isPressed = true;
                pressedkey = Keys.Up;
            }
            else if (e.KeyCode == Keys.Left)
            {
                x = x - 5;
                row = 1;
                isPressed = true;
                pressedkey = Keys.Left;
            }
            else if (e.KeyCode == Keys.Right)
            {
                x = x + 5;
                row = 2;
                isPressed = true;
                pressedkey = Keys.Right;
            }
            ChangeFrame();

        }
        void ChangeFrame()
        {
            if (column != 3)
                column++;
            else column = 0;
        }
    }
}

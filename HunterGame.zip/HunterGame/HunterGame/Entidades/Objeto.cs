﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HunterGame.Mecanicas;
namespace HunterGame.Entidades
{
    public class Objeto
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public int cantidad { get; set; }

        public Objeto(int id, string nombre,string descripcion, int cantidad )
        {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.cantidad = cantidad;
        }
    }
}

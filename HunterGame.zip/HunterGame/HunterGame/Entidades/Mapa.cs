﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HunterGame.Mecanicas;
namespace HunterGame.Entidades
{
    class Mapa
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string value { get; set; }
        public int[,] atributos { get; set; }
        public Map Map { get; set; }
        public int sizex { get; set; }
        public int sizey { get; set; }
        public Mapa(int id, string nombre, string value, int[,] atributos)
        {
            this.id = id;
            this.nombre = nombre;
            this.value = value;
            this.atributos = atributos;
            Map = new Map(this.value);
        }
        public Mapa(string nombre, string value)
        {
            this.nombre = nombre;
            this.value = value;
            Map = new Map(this.value);
        }
    }
}

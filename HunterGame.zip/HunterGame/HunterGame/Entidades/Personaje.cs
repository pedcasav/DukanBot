﻿using SFML.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HunterGame.Mecanicas;

namespace HunterGame.Entidades
{
    class Personaje
    {
        public string nickname { get; set; }
        public int sex { get; set; }
        public int lugarInicial { get; set; }
        public Apariencia Apariencia { get; set; }
        public int nivel { get; set; }
        public int exp { get; set; }
        public int acceso { get; set; }
        public int asesinatos { get; set; }
        public List<Objeto> Inventario { get; set; }
        public Objeto[] Equipamento { get; set; }
        public Atributos Atributos { get; set; }
        public int mapaActual { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int vida { get; set; }
        public int nen { get; set; }
        public Player Player { get; set; }

        //extra fields
        int actualHealth;

        public Personaje(string nickname,int sex,int lugarInicial,Apariencia Apariencia,int nivel,int exp, int acceso, int asesinatos, List<Objeto> Inventario, Objeto[] Equipamento, Atributos Atributos, int mapaActual, int X, int Y, int vida, int nen)
        {
            this.nickname = nickname;
            this.sex = sex;
            this.lugarInicial = lugarInicial;
            this.Apariencia = Apariencia;
            this.nivel = nivel;
            this.exp = exp;
            this.acceso = acceso;
            this.asesinatos = asesinatos;
            this.Inventario = Inventario;
            this.Equipamento = Equipamento;
            this.Atributos = Atributos;
            this.mapaActual = mapaActual;
            this.X = X;
            this.Y = Y;
            this.vida = vida;
            this.nen = nen;
            Player = new Player(this.X,this.Y,this.vida);
        }
        public void ResetHealth(int health)
        {
            actualHealth = vida = health;
        }
        
    }
}

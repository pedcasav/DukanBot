﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HunterGame.Mecanicas;
namespace HunterGame.Entidades
{
    public class Cuenta
    {
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public int lenguaje { get; set; }
        public int acceso { get; set; }
    }
}

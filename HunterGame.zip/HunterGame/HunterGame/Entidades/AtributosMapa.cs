﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HunterGame.Entidades
{
    public class AtributosMapa
    {
        public int id { get; set; }
        public string value1 { get; set; }
        public int value2 { get; set; }
        public int value3 { get; set; }
        public int value4 { get; set; }
        public int value5 { get; set; }
        public AtributosMapa(int id, string value1,int value2, int value3, int value4 ,int value5)
        {
            this.id = id;
            this.value1 = value1;
            this.value2 = value2;
            this.value3 = value3;
            this.value4 = value4;
            this.value5 = value5;
        }
        public AtributosMapa(int id)
        {
            this.id = id;
            this.value1 = "";
            this.value2 = 0;
            this.value3 = 0;
            this.value4 = 0;
            this.value5 = 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HunterGame.Entidades;

namespace HunterGame.Editores
{
    public partial class Warp : Form
    {
        int Myself;
        public Warp(string username)
        {
            Myself = Functions.lookPJ(username);
            InitializeComponent();
        }

        private void rbOther_CheckedChanged(object sender, EventArgs e)
        {
            txtTarget.Text = "";
            if (rbOther.Checked) txtTarget.Enabled = true;
            else txtTarget.Enabled = false;
        }

        private void rbMyself_CheckedChanged(object sender, EventArgs e)
        {
            txtTarget.Text = "";
            if (rbOther.Checked) txtTarget.Enabled = true;
            else txtTarget.Enabled = false;
        }

        private void btnMover_Click(object sender, EventArgs e)
        {
            int n;
            if (int.TryParse(txtMap.Text, out n) && (txtTarget.Text != "" || txtTarget.Enabled == false))
            {
                if (n > Global.Mapas.Count || n < 1)
                {
                    MessageBox.Show("El mapa no existe");
                    return;
                }

                if (txtTarget.Enabled)
                {
                    int target = Functions.lookPJ(txtTarget.Text);
                    if (target == -1)
                    {
                        MessageBox.Show("No pudimos encontrar al personaje");
                        return;
                    }
                    if (Global.Personajes[target].mapaActual != n-1)
                        Global.Personajes[target].mapaActual = n - 1;
                    else
                        MessageBox.Show("El personaje ya se encontraba en ese lugar");
                }
                else
                {
                    if (Global.Personajes[Myself].mapaActual != n-1)
                        Global.Personajes[Myself].mapaActual = n - 1;
                    else
                        MessageBox.Show("Ya te encuentras en ese lugar");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            eMain.openForm = false;
            Dispose();
        }
    }
}

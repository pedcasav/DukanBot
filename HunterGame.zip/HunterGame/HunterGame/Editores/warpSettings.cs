﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HunterGame.Editores
{
    public partial class warpSettings : Form
    {
        public int map = 0, x = 0, y = 0, mode = 0;

        private void btnAisgnar_Click(object sender, EventArgs e)
        {
            int n;
            if (int.TryParse(txtMap.Text, out n) && int.TryParse(txtX.Text, out n) && int.TryParse(txtY.Text, out n))
            {
                map = int.Parse(txtMap.Text);
                x = int.Parse(txtX.Text);
                y = int.Parse(txtY.Text);
                mode = 1;
                Dispose();
            }
            else MessageBox.Show("Los formatos ingresados no son correctos.");
        }

        public warpSettings()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}

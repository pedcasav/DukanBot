﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Window;

namespace HunterGame.Editores
{
    public class eMain
    {
        public static bool openForm = false;
        public static void Functions(string myself)
        {
            if (!openForm)
                if (Keyboard.IsKeyPressed(Keyboard.Key.F1))
                {
                    openForm = true;
                    new eMapa().Show();
                }
                else if (Keyboard.IsKeyPressed(Keyboard.Key.F2))
                {
                    openForm = true;
                    new Warp(myself).Show();
                }
        }
    }
}

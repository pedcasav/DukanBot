﻿namespace HunterGame.Editores
{
    partial class eMapa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCrear = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.pMapa = new System.Windows.Forms.Panel();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbMapa = new System.Windows.Forms.PictureBox();
            this.pAtributos = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.att1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.mMapas = new System.Windows.Forms.TrackBar();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.pMapaImage = new System.Windows.Forms.Panel();
            this.pMapa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMapa)).BeginInit();
            this.pAtributos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mMapas)).BeginInit();
            this.pMapaImage.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(12, 12);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(107, 25);
            this.btnCrear.TabIndex = 0;
            this.btnCrear.Text = "CREAR MAPA";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(12, 43);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(107, 25);
            this.btnEditar.TabIndex = 1;
            this.btnEditar.Text = "EDITAR MAPA";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // pMapa
            // 
            this.pMapa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pMapa.Controls.Add(this.txtValor);
            this.pMapa.Controls.Add(this.label2);
            this.pMapa.Controls.Add(this.btnGuardar);
            this.pMapa.Controls.Add(this.txtNombre);
            this.pMapa.Controls.Add(this.label1);
            this.pMapa.Location = new System.Drawing.Point(12, 122);
            this.pMapa.Name = "pMapa";
            this.pMapa.Size = new System.Drawing.Size(107, 147);
            this.pMapa.TabIndex = 2;
            this.pMapa.Visible = false;
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(3, 76);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(101, 23);
            this.txtValor.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Valor";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(17, 105);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "Crear";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(3, 32);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(101, 23);
            this.txtNombre.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre";
            // 
            // pbMapa
            // 
            this.pbMapa.Location = new System.Drawing.Point(0, 0);
            this.pbMapa.Name = "pbMapa";
            this.pbMapa.Size = new System.Drawing.Size(100, 100);
            this.pbMapa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbMapa.TabIndex = 3;
            this.pbMapa.TabStop = false;
            // 
            // pAtributos
            // 
            this.pAtributos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pAtributos.Controls.Add(this.radioButton2);
            this.pAtributos.Controls.Add(this.radioButton1);
            this.pAtributos.Controls.Add(this.att1);
            this.pAtributos.Controls.Add(this.label3);
            this.pAtributos.Location = new System.Drawing.Point(12, 122);
            this.pAtributos.Name = "pAtributos";
            this.pAtributos.Size = new System.Drawing.Size(107, 119);
            this.pAtributos.TabIndex = 4;
            this.pAtributos.Visible = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(3, 78);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(39, 19);
            this.radioButton2.TabIndex = 8;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "TP";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(3, 53);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 19);
            this.radioButton1.TabIndex = 7;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Bloqueo";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // att1
            // 
            this.att1.AutoSize = true;
            this.att1.Location = new System.Drawing.Point(3, 28);
            this.att1.Name = "att1";
            this.att1.Size = new System.Drawing.Size(53, 19);
            this.att1.TabIndex = 6;
            this.att1.TabStop = true;
            this.att1.Text = "Nada";
            this.att1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Atributos";
            // 
            // mMapas
            // 
            this.mMapas.Location = new System.Drawing.Point(12, 74);
            this.mMapas.Name = "mMapas";
            this.mMapas.Size = new System.Drawing.Size(107, 42);
            this.mMapas.TabIndex = 5;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Enabled = false;
            this.btnCancelar.Location = new System.Drawing.Point(12, 275);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(107, 23);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // pMapaImage
            // 
            this.pMapaImage.AutoScroll = true;
            this.pMapaImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pMapaImage.Controls.Add(this.pbMapa);
            this.pMapaImage.Location = new System.Drawing.Point(125, 12);
            this.pMapaImage.Name = "pMapaImage";
            this.pMapaImage.Size = new System.Drawing.Size(941, 664);
            this.pMapaImage.TabIndex = 6;
            // 
            // eMapa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 688);
            this.Controls.Add(this.pMapaImage);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.mMapas);
            this.Controls.Add(this.pMapa);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.pAtributos);
            this.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "eMapa";
            this.Text = "eMapa";
            this.pMapa.ResumeLayout(false);
            this.pMapa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMapa)).EndInit();
            this.pAtributos.ResumeLayout(false);
            this.pAtributos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mMapas)).EndInit();
            this.pMapaImage.ResumeLayout(false);
            this.pMapaImage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Panel pMapa;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbMapa;
        private System.Windows.Forms.Panel pAtributos;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton att1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar mMapas;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Panel pMapaImage;
    }
}
﻿namespace HunterGame.Editores
{
    partial class eMapa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCrear = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.pMapa = new System.Windows.Forms.Panel();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbMapa = new System.Windows.Forms.PictureBox();
            this.pAtributos = new System.Windows.Forms.Panel();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.cGrid = new System.Windows.Forms.CheckBox();
            this.cAtributos = new System.Windows.Forms.CheckBox();
            this.rTP = new System.Windows.Forms.RadioButton();
            this.rBloqueo = new System.Windows.Forms.RadioButton();
            this.rNada = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.mMapas = new System.Windows.Forms.TrackBar();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.pMapaImage = new System.Windows.Forms.Panel();
            this.pMapa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMapa)).BeginInit();
            this.pAtributos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mMapas)).BeginInit();
            this.pMapaImage.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(12, 12);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(107, 25);
            this.btnCrear.TabIndex = 0;
            this.btnCrear.Text = "CREAR MAPA";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(12, 43);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(107, 25);
            this.btnEditar.TabIndex = 1;
            this.btnEditar.Text = "EDITAR MAPA";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // pMapa
            // 
            this.pMapa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pMapa.Controls.Add(this.txtValor);
            this.pMapa.Controls.Add(this.label2);
            this.pMapa.Controls.Add(this.btnGuardar);
            this.pMapa.Controls.Add(this.txtNombre);
            this.pMapa.Controls.Add(this.label1);
            this.pMapa.Location = new System.Drawing.Point(12, 122);
            this.pMapa.Name = "pMapa";
            this.pMapa.Size = new System.Drawing.Size(107, 147);
            this.pMapa.TabIndex = 2;
            this.pMapa.Visible = false;
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(3, 76);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(101, 23);
            this.txtValor.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Valor";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(17, 105);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "Crear";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(3, 32);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(101, 23);
            this.txtNombre.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre";
            // 
            // pbMapa
            // 
            this.pbMapa.Location = new System.Drawing.Point(0, 0);
            this.pbMapa.Name = "pbMapa";
            this.pbMapa.Size = new System.Drawing.Size(100, 100);
            this.pbMapa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbMapa.TabIndex = 3;
            this.pbMapa.TabStop = false;
            this.pbMapa.Paint += new System.Windows.Forms.PaintEventHandler(this.pbMapa_Paint);
            this.pbMapa.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbMapa_MouseClick);
            // 
            // pAtributos
            // 
            this.pAtributos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pAtributos.Controls.Add(this.btnActualizar);
            this.pAtributos.Controls.Add(this.cGrid);
            this.pAtributos.Controls.Add(this.cAtributos);
            this.pAtributos.Controls.Add(this.rTP);
            this.pAtributos.Controls.Add(this.rBloqueo);
            this.pAtributos.Controls.Add(this.rNada);
            this.pAtributos.Controls.Add(this.label3);
            this.pAtributos.Location = new System.Drawing.Point(12, 122);
            this.pAtributos.Name = "pAtributos";
            this.pAtributos.Size = new System.Drawing.Size(107, 192);
            this.pAtributos.TabIndex = 4;
            this.pAtributos.Visible = false;
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(3, 159);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(99, 23);
            this.btnActualizar.TabIndex = 7;
            this.btnActualizar.Text = "Guardar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // cGrid
            // 
            this.cGrid.AutoSize = true;
            this.cGrid.Location = new System.Drawing.Point(3, 134);
            this.cGrid.Name = "cGrid";
            this.cGrid.Size = new System.Drawing.Size(54, 19);
            this.cGrid.TabIndex = 9;
            this.cGrid.Text = "Grilla";
            this.cGrid.UseVisualStyleBackColor = true;
            this.cGrid.CheckedChanged += new System.EventHandler(this.cGrid_CheckedChanged);
            // 
            // cAtributos
            // 
            this.cAtributos.AutoSize = true;
            this.cAtributos.Location = new System.Drawing.Point(3, 109);
            this.cAtributos.Name = "cAtributos";
            this.cAtributos.Size = new System.Drawing.Size(78, 19);
            this.cAtributos.TabIndex = 4;
            this.cAtributos.Text = "Atributos";
            this.cAtributos.UseVisualStyleBackColor = true;
            this.cAtributos.CheckedChanged += new System.EventHandler(this.cGrid_CheckedChanged);
            // 
            // rTP
            // 
            this.rTP.AutoSize = true;
            this.rTP.Location = new System.Drawing.Point(3, 78);
            this.rTP.Name = "rTP";
            this.rTP.Size = new System.Drawing.Size(39, 19);
            this.rTP.TabIndex = 8;
            this.rTP.Text = "TP";
            this.rTP.UseVisualStyleBackColor = true;
            this.rTP.CheckedChanged += new System.EventHandler(this.rTP_CheckedChanged);
            // 
            // rBloqueo
            // 
            this.rBloqueo.AutoSize = true;
            this.rBloqueo.Location = new System.Drawing.Point(3, 53);
            this.rBloqueo.Name = "rBloqueo";
            this.rBloqueo.Size = new System.Drawing.Size(71, 19);
            this.rBloqueo.TabIndex = 7;
            this.rBloqueo.Text = "Bloqueo";
            this.rBloqueo.UseVisualStyleBackColor = true;
            // 
            // rNada
            // 
            this.rNada.AutoSize = true;
            this.rNada.Checked = true;
            this.rNada.Location = new System.Drawing.Point(3, 28);
            this.rNada.Name = "rNada";
            this.rNada.Size = new System.Drawing.Size(53, 19);
            this.rNada.TabIndex = 6;
            this.rNada.TabStop = true;
            this.rNada.Text = "Nada";
            this.rNada.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Atributos";
            // 
            // mMapas
            // 
            this.mMapas.Location = new System.Drawing.Point(12, 74);
            this.mMapas.Name = "mMapas";
            this.mMapas.Size = new System.Drawing.Size(107, 42);
            this.mMapas.TabIndex = 5;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Enabled = false;
            this.btnCancelar.Location = new System.Drawing.Point(12, 320);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(107, 23);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // pMapaImage
            // 
            this.pMapaImage.AutoScroll = true;
            this.pMapaImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pMapaImage.Controls.Add(this.pbMapa);
            this.pMapaImage.Location = new System.Drawing.Point(125, 12);
            this.pMapaImage.Name = "pMapaImage";
            this.pMapaImage.Size = new System.Drawing.Size(941, 664);
            this.pMapaImage.TabIndex = 6;
            // 
            // eMapa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 688);
            this.Controls.Add(this.pAtributos);
            this.Controls.Add(this.pMapaImage);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.mMapas);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.pMapa);
            this.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "eMapa";
            this.Text = "eMapa";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.eMapa_FormClosing);
            this.pMapa.ResumeLayout(false);
            this.pMapa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMapa)).EndInit();
            this.pAtributos.ResumeLayout(false);
            this.pAtributos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mMapas)).EndInit();
            this.pMapaImage.ResumeLayout(false);
            this.pMapaImage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Panel pMapa;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbMapa;
        private System.Windows.Forms.Panel pAtributos;
        private System.Windows.Forms.RadioButton rTP;
        private System.Windows.Forms.RadioButton rBloqueo;
        private System.Windows.Forms.RadioButton rNada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar mMapas;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Panel pMapaImage;
        private System.Windows.Forms.CheckBox cAtributos;
        private System.Windows.Forms.CheckBox cGrid;
        private System.Windows.Forms.Button btnActualizar;
    }
}
﻿namespace HunterGame.Editores
{
    partial class Warp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbMyself = new System.Windows.Forms.RadioButton();
            this.rbOther = new System.Windows.Forms.RadioButton();
            this.txtTarget = new System.Windows.Forms.TextBox();
            this.txtMap = new System.Windows.Forms.TextBox();
            this.btnMover = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rbMyself
            // 
            this.rbMyself.AutoSize = true;
            this.rbMyself.Checked = true;
            this.rbMyself.Location = new System.Drawing.Point(12, 12);
            this.rbMyself.Name = "rbMyself";
            this.rbMyself.Size = new System.Drawing.Size(79, 19);
            this.rbMyself.TabIndex = 0;
            this.rbMyself.TabStop = true;
            this.rbMyself.Text = "Moverme";
            this.rbMyself.UseVisualStyleBackColor = true;
            this.rbMyself.CheckedChanged += new System.EventHandler(this.rbMyself_CheckedChanged);
            // 
            // rbOther
            // 
            this.rbOther.AutoSize = true;
            this.rbOther.Location = new System.Drawing.Point(156, 12);
            this.rbOther.Name = "rbOther";
            this.rbOther.Size = new System.Drawing.Size(70, 19);
            this.rbOther.TabIndex = 1;
            this.rbOther.Text = "Mover a";
            this.rbOther.UseVisualStyleBackColor = true;
            this.rbOther.CheckedChanged += new System.EventHandler(this.rbOther_CheckedChanged);
            // 
            // txtTarget
            // 
            this.txtTarget.Enabled = false;
            this.txtTarget.Location = new System.Drawing.Point(12, 56);
            this.txtTarget.Name = "txtTarget";
            this.txtTarget.Size = new System.Drawing.Size(138, 23);
            this.txtTarget.TabIndex = 2;
            // 
            // txtMap
            // 
            this.txtMap.Location = new System.Drawing.Point(156, 56);
            this.txtMap.Name = "txtMap";
            this.txtMap.Size = new System.Drawing.Size(70, 23);
            this.txtMap.TabIndex = 3;
            // 
            // btnMover
            // 
            this.btnMover.Location = new System.Drawing.Point(46, 109);
            this.btnMover.Name = "btnMover";
            this.btnMover.Size = new System.Drawing.Size(75, 23);
            this.btnMover.TabIndex = 4;
            this.btnMover.Text = "Mover";
            this.btnMover.UseVisualStyleBackColor = true;
            this.btnMover.Click += new System.EventHandler(this.btnMover_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(127, 109);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // Warp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 144);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnMover);
            this.Controls.Add(this.txtMap);
            this.Controls.Add(this.txtTarget);
            this.Controls.Add(this.rbOther);
            this.Controls.Add(this.rbMyself);
            this.Font = new System.Drawing.Font("Candara", 9.75F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Warp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Warp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbMyself;
        private System.Windows.Forms.RadioButton rbOther;
        private System.Windows.Forms.TextBox txtTarget;
        private System.Windows.Forms.TextBox txtMap;
        private System.Windows.Forms.Button btnMover;
        private System.Windows.Forms.Button btnCancelar;
    }
}
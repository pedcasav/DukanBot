﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HunterGame.Entidades;
using System.IO;

namespace HunterGame.Editores
{
    public partial class eMapa : Form
    {
        private enum FormState
        {
            None,
            Create,
            Edit,
            Delete
        }
        public eMapa()
        {
            InitializeComponent();
            mMapas.Minimum = 1;
            mMapas.Maximum = Global.Mapas.Count;
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            setFormState(FormState.Create);
        }
        private void setFormState(FormState FormState)
        {
            txtNombre.Text = "";
            txtValor.Text = "";
            if (FormState == FormState.Create)
            {
                btnCrear.Enabled = false;
                btnEditar.Enabled = false;
                pMapa.Visible = true;
                pAtributos.Visible = false;
                btnCancelar.Enabled = true;
                mMapas.Enabled = false;
            }
            if (FormState == FormState.None)
            {
                btnCrear.Enabled = true;
                btnEditar.Enabled = true;
                pMapa.Visible = false;
                pAtributos.Visible = false;
                btnCancelar.Enabled = false;
                mMapas.Enabled = true;
            }
            if (FormState == FormState.Edit)
            {
                btnCrear.Enabled = false;
                btnEditar.Enabled = false;
                pMapa.Visible = false;
                pAtributos.Visible = true;
                btnCancelar.Enabled = true;
                mMapas.Enabled = false;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text.Length > 0 && txtValor.Text.Length > 0)
            {
                Mapa Mapa = new Mapa(txtNombre.Text, txtValor.Text);
                Image Image = Image.FromFile(Mapa.Map.url);
                Mapa.sizex = Image.Size.Width / 32;
                Mapa.sizey = Image.Size.Height / 32;
                Mapa.atributos = new int[Image.Size.Width / 32, Image.Size.Height / 32];

                FillArray(Mapa.atributos, Image.Size.Width / 32, Image.Size.Height / 32);
                CreateFile(Mapa.atributos, Image.Size.Width / 32, Image.Size.Height / 32, Mapa);
                
            }
        }
        private void FillArray(int[,] array,int limitx, int limity)
        {
            for (int x = 0; x < limitx; x++)
            {
                for (int y = 0; y < limity; y++)
                {
                    array[x, y] = 0;
                }
            }
        }
        private void CreateFile(int[,] array, int limitx, int limity,Mapa Mapa)
        {            
            using (StreamWriter sw = File.AppendText(Application.StartupPath + @"\map\" + Mapa.value + ".csv"))
            {
                for (int x = 0; x < limitx; x++)
                {
                    for (int y = 0; y < limity; y++)
                    {
                        if (y != limity - 1)
                            sw.Write(array[x, y] + ",");
                        else
                            sw.Write(array[x, y]);
                    }
                    sw.Write("\n");
                }
            }
            using (StreamWriter sw = File.AppendText(Application.StartupPath + @"\map\Mapas.pca"))
            {
                sw.WriteLine(Mapa.nombre + "," + Mapa.value + "," + Mapa.sizex + "," + Mapa.sizey);
            }
            DialogResult dr = MessageBox.Show("El mapa fue guardado. Deseas Editarlo?","Mensaje",MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                setFormState(FormState.Edit);
                pbMapa.Image = Image.FromFile(Mapa.Map.url);
                drawLines(pbMapa.Image);
            }
            else
            {
                setFormState(FormState.None);
            }
        }
        private void drawLines(Image Image)
        {
            using (Graphics g = pbMapa.CreateGraphics())
            {
                int numOfCells = 200;
                int cellSize = 5;
                Pen p = new Pen(Color.Black);

                for (int y = 0; y < numOfCells; ++y)
                {
                    g.DrawLine(p, 0, y * cellSize, numOfCells * cellSize, y * cellSize);
                }

                for (int x = 0; x < numOfCells; ++x)
                {
                    g.DrawLine(p, x * cellSize, 0, x * cellSize, numOfCells * cellSize);
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            pbMapa.Image = Image.FromFile(Global.Mapas[mMapas.Value-1].Map.url);
            drawLines(pbMapa.Image);
        }
    }
}

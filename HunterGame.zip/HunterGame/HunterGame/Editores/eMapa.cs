﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HunterGame.Entidades;
using System.IO;

namespace HunterGame.Editores
{
    public partial class eMapa : Form
    {
        private enum FormState
        {
            None,
            Create,
            Edit,
            Delete
        }
        AtributosMapa actualmapat = null;
        private FormState actualState = FormState.None;
        private Mapa actualMap = null;
        private Image actualImage = null;
        public eMapa()
        {
            InitializeComponent();
            mMapas.Minimum = 1;
            mMapas.Maximum = Global.Mapas.Count;
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            actualState = FormState.Create;
            setFormState();
        }
        private void setFormState()
        {
            txtNombre.Text = "";
            txtValor.Text = "";
            if (actualState == FormState.Create)
            {
                btnCrear.Enabled = false;
                btnEditar.Enabled = false;
                pMapa.Visible = true;
                pAtributos.Visible = false;
                btnCancelar.Enabled = true;
                mMapas.Enabled = false;
            }
            if (actualState == FormState.None)
            {
                btnCrear.Enabled = true;
                btnEditar.Enabled = true;
                pMapa.Visible = false;
                pAtributos.Visible = false;
                btnCancelar.Enabled = false;
                mMapas.Enabled = true;
            }
            if (actualState == FormState.Edit)
            {
                btnCrear.Enabled = false;
                btnEditar.Enabled = false;
                pMapa.Visible = false;
                pAtributos.Visible = true;
                btnCancelar.Enabled = true;
                mMapas.Enabled = false;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text.Length > 0 && txtValor.Text.Length > 0)
            {
                Mapa Mapa = new Mapa(txtNombre.Text, txtValor.Text);
                Image Image = Image.FromFile(Mapa.Map.url);
                Mapa.sizex = Image.Size.Width / 32;
                Mapa.sizey = Image.Size.Height / 32;
                Mapa.atributos = new AtributosMapa[Image.Size.Width / 32, Image.Size.Height / 32];

                FillArray(Mapa.atributos, Image.Size.Width / 32, Image.Size.Height / 32);
                CreateFile(Mapa.atributos, Image.Size.Width / 32, Image.Size.Height / 32, Mapa);

            }
        }
        private void FillArray(AtributosMapa[,] array, int limitx, int limity)
        {
            for (int x = 0; x < limitx; x++)
            {
                for (int y = 0; y < limity; y++)
                {
                    array[x, y] = new AtributosMapa(0);
                }
            }
        }
        //SAVING EDITED MAP
        private void CreateFile(AtributosMapa[,] array, int limitx, int limity, Mapa Mapa)
        {
            using (StreamWriter sw = File.CreateText(Application.StartupPath + @"\map\" + Mapa.value + ".csv"))
            {
                for (int x = 0; x < limitx; x++)
                {
                    for (int y = 0; y < limity; y++)
                    {
                        if (y != limity - 1)
                            sw.Write(array[x, y].id + ";" + array[x, y].value1 + ";" + array[x, y].value2 + ";" + array[x, y].value3 + ";" + array[x, y].value4 + ";" + array[x, y].value5 + ",");
                        else
                            sw.Write(array[x, y].id + ";" + array[x, y].value1 + ";" + array[x, y].value2 + ";" + array[x, y].value3 + ";" + array[x, y].value4 + ";" + array[x, y].value5);
                    }
                    sw.Write("\n");
                }
            }
            Global.Mapas.Add(Mapa);
            DialogResult dr = MessageBox.Show("El mapa fue guardado. Deseas seguir editandolo?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                actualState = (FormState.Edit);
                setFormState();
                pbMapa.Image = Image.FromFile(Mapa.Map.url);
                actualImage = pbMapa.Image;
            }
            else
            {
                actualState = (FormState.None);
                setFormState();
            }
        }
        private void UpdateFile(AtributosMapa[,] array, int limitx, int limity, Mapa Mapa)
        {
            using (StreamWriter sw = File.CreateText(Application.StartupPath + @"\map\" + Mapa.value + ".csv"))
            {
                for (int x = 0; x < limitx; x++)
                {
                    for (int y = 0; y < limity; y++)
                    {
                        if (y != limity - 1)
                            sw.Write(array[x, y].id + ";" + array[x, y].value1 + ";" + array[x, y].value2 + ";" + array[x, y].value3 + ";" + array[x, y].value4 + ";" + array[x, y].value5 + ",");
                        else
                            sw.Write(array[x, y].id + ";" + array[x, y].value1 + ";" + array[x, y].value2 + ";" + array[x, y].value3 + ";" + array[x, y].value4 + ";" + array[x, y].value5);
                    }
                    sw.Write("\n");
                }
            }
            using (StreamWriter sw = File.AppendText(Application.StartupPath + @"\map\Mapas.pca"))
            {
                sw.WriteLine(Mapa.nombre + "," + Mapa.value + "," + Mapa.sizex + "," + Mapa.sizey);
            }
            DialogResult dr = MessageBox.Show("El mapa fue guardado. Deseas Editarlo?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                actualState = (FormState.Edit);
                setFormState();
                pbMapa.Image = Image.FromFile(Mapa.Map.url);
                actualImage = pbMapa.Image;
            }
            else
            {
                actualState = (FormState.None);
                setFormState();
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            actualState = FormState.Edit;
            actualMap = Global.Mapas[mMapas.Value - 1];
            actualImage = Image.FromFile(actualMap.Map.url);
            setFormState();
            drawGridAtt();

        }
        private void drawGridAtt()
        {
            Bitmap bitmap = new Bitmap(actualImage);
            if (cAtributos.Checked) setAtt(bitmap);
            if (cGrid.Checked) setGrid(bitmap);
            pbMapa.Image = bitmap;
        }
        void setAtt(Bitmap bitmap)
        {
            int columns = bitmap.Width / 32;
            int rows = bitmap.Height / 32;
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                using (Font arialFont = new Font("Arial", 10))
                {
                    for (int y = 0; y < rows; y++)
                    {
                        for (int x = 0; x < columns; x++)
                        {
                            graphics.DrawString(setAttribute(actualMap.atributos[x, y].id), arialFont, Brushes.White, new PointF(x * 32 + 10, y * 32 + 10));
                        }
                    }
                }
            }
        }
        void setGrid(Bitmap bitmap)
        {
            int columns = bitmap.Width / 32;
            int rows = bitmap.Height / 32;
            Pen p = new Pen(Color.White);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                for (int x = 1; x <= columns; x++)
                {
                    g.DrawLine(p, new Point(x * 32, 0), new Point(x * 32, bitmap.Height));
                }
                for (int y = 1; y <= rows; y++)
                {
                    g.DrawLine(p, new Point(0, y * 32), new Point(bitmap.Width, y * 32));
                }
            }
        }
        private string setAttribute(int attribute)
        {
            if (attribute == 0) return "N";
            else if (attribute == 1) return "B";
            else return "W";
        }
        private AtributosMapa getAttribute()
        {
            if (rNada.Checked) return new AtributosMapa(0);
            else if (rBloqueo.Checked) return new AtributosMapa(1);
            else
            {
                return actualmapat;
            }
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            
            actualState = (FormState.None);
            setFormState();
        }

        private void pbMapa_Paint(object sender, PaintEventArgs e)
        {            
        }

        private void btnGrid_Click(object sender, EventArgs e)
        {
            drawGridAtt();
        }
        private void eMapa_FormClosing(object sender, FormClosingEventArgs e)
        {
            eMain.openForm = false; 
        }

        private void cGrid_CheckedChanged(object sender, EventArgs e)
        {
            drawGridAtt();
        }

        private void pbMapa_MouseClick(object sender, MouseEventArgs e)
        {
            AtributosMapa att = getAttribute();
            int x = e.X / 32;
            int y = e.Y / 32;
            actualMap.atributos[x, y] = att;
            drawGridAtt();
        }

        private void rTP_CheckedChanged(object sender, EventArgs e)
        {
            if (!rTP.Checked) return;
            warpSettings frm = new warpSettings();
            frm.ShowDialog();
            if (frm.mode == 0)
            {
                actualmapat = new AtributosMapa(0);
                return;
            }
            actualmapat = new AtributosMapa(2, "", frm.map, frm.x, frm.y, 0);


        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {

            UpdateFile(actualMap.atributos, actualMap.sizex, actualMap.sizey, actualMap);
        }
    }
}

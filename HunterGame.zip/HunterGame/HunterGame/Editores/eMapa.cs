﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HunterGame.Entidades;


namespace HunterGame.Editores
{
    public partial class eMapa : Form
    {
        List<Mapa> Mapas = new List<Mapa>();
        public eMapa()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            pMapa.Visible = true;
            btnCrear.Enabled = false;
            btnEditar.Enabled = false;
            btnCancelar.Enabled = true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text.Length > 0 && txtValor.Text.Length > 0)
            {
                Mapa Mapa = new Mapa(txtNombre.Text,txtValor.Text);
                Image Image = Image.FromFile(Mapa.Map.url);
                Mapa.atributos = new int[Image.Size.Width / 32, Image.Size.Height / 32];

            }
        }
    }
}

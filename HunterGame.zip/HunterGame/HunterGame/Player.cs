﻿using SFML.Window;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HunterGame
{
    class Player : AnimatedCharacter
    {
        public Player() : base(Application.StartupPath + @"\thelegal.png")
        {
            moveSpeed = 150;
            animationSpeed = 0.05f;
        }
        public override void Update(float deltaTime)
        {
            this.CurrentState = CharacterState.None;

            if (Keyboard.IsKeyPressed(Keyboard.Key.Up))
            {
                this.CurrentState = CharacterState.MovingUp;
            }
            else if (Keyboard.IsKeyPressed(Keyboard.Key.Down))
            {
                this.CurrentState = CharacterState.MovingDown;
            }
            else if (Keyboard.IsKeyPressed(Keyboard.Key.Left))
            {
                this.CurrentState = CharacterState.MovingLeft;
            }
            else if (Keyboard.IsKeyPressed(Keyboard.Key.Right))
            {
                this.CurrentState = CharacterState.MovingRight;
            }

            base.Update(deltaTime);
        }
    }
}

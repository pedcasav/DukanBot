﻿using SFML.Window;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SFML.Graphics;
using SFML.System;

namespace HunterGame.Mecanicas
{
    class Player : AnimatedCharacter
    {
        public Player(int mapa, float xpos, float ypos,int vida) : base(Application.StartupPath + @"\thelegal.png",mapa,xpos,ypos,vida)
        {
            moveSpeed = 150;
            animationSpeed = 0.08f;
            map = mapa;
            
        }
        public override void Update(float deltaTime)
        {
            this.CurrentState = CharacterState.None;

            if (Keyboard.IsKeyPressed(Keyboard.Key.Up))
            {
                this.CurrentState = CharacterState.MovingUp;
            }
            else if (Keyboard.IsKeyPressed(Keyboard.Key.Down))
            {
                this.CurrentState = CharacterState.MovingDown;
            }
            else if (Keyboard.IsKeyPressed(Keyboard.Key.Left))
            {
                this.CurrentState = CharacterState.MovingLeft;
            }
            else if (Keyboard.IsKeyPressed(Keyboard.Key.Right))
            {
                this.CurrentState = CharacterState.MovingRight;
            }
            else if(Keyboard.IsKeyPressed(Keyboard.Key.A))
            {
                this.CurrentState = CharacterState.Attack;
            }

            base.Update(deltaTime);
        }
    }
}

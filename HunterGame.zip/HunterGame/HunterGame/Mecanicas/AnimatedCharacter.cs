﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HunterGame.Mecanicas
{
    public enum CharacterState
    {
        None,
        MovingUp,
        MovingLeft,
        MovingDown,
        MovingRight,
        Attack
    }
    abstract class AnimatedCharacter
    {
        public float Xpos { get; set; }
        public float Ypos { get; set; }
        private Sprite sprite;
        private IntRect spriteRect;
        private int xFrameSize;
        private int yFrameSize;
        public CharacterState CurrentState { get; set; }

        protected Animation Anim_Up;
        protected Animation Anim_Left;
        protected Animation Anim_Down;
        protected Animation Anim_Right;

        private Clock animationClock;
        protected float moveSpeed = 50;
        protected float animationSpeed = 0.1f;


        //Barra de vida
        Shape rec;
        private int VidaTotal;
        private int vidaActual;

        public AnimatedCharacter(string filename,float Xpos, float Ypos,int vida)
        {
            
            Texture texture = new Texture(filename);
            xFrameSize = (int)texture.Size.X / 4;
            yFrameSize = (int)texture.Size.Y / 4;
            spriteRect = new IntRect(0, 0, xFrameSize,yFrameSize);
            rec = new RectangleShape(new Vector2f(xFrameSize, 10));
            sprite = new Sprite(texture, spriteRect);
            this.Xpos = Xpos;
            this.Ypos = Ypos;
            VidaTotal = vida;
            vidaActual = VidaTotal;
            Anim_Down = new Animation(0, 0, 4);
            Anim_Left = new Animation((int)texture.Size.Y / 4, 0, 4);
            Anim_Right = new Animation((int)texture.Size.Y * 2 / 4, 0, 4);
            Anim_Up = new Animation((int)texture.Size.Y * 3 / 4, 0, 4);

            animationClock = new Clock();
            rec.FillColor = Color.Red;
            rec.Position = new Vector2f(Xpos, Ypos - 10);
            
        }

        public virtual void Update(float deltaTime)
        {
            Animation currentAnimation = null;
            switch (CurrentState)
            {
                case CharacterState.MovingUp:
                    if (Ypos <= 0) return;
                    currentAnimation = Anim_Up;
                    Ypos -= moveSpeed * deltaTime;
                    break;
                case CharacterState.MovingLeft:
                    if (Xpos <= 0) return;
                    currentAnimation = Anim_Left;
                    Xpos -= moveSpeed * deltaTime;
                    break;
                case CharacterState.MovingDown:
                    currentAnimation = Anim_Down;
                    Ypos += moveSpeed * deltaTime;
                    
                    break;
                case CharacterState.MovingRight:
                    currentAnimation = Anim_Right;
                    Xpos += moveSpeed * deltaTime;
                    break;
                case CharacterState.Attack:
                    vidaActual--;
                    rec = new RectangleShape(new Vector2f(xFrameSize * vidaActual / VidaTotal, 10));
                    break;
            }
            sprite.Position = new Vector2f(Xpos, Ypos);
            rec.Position = new Vector2f(Xpos, Ypos - 10);
            if (animationClock.ElapsedTime.AsSeconds() > animationSpeed)
            {
                if (currentAnimation != null)
                {
                    spriteRect.Top = currentAnimation.offsetTop;
                    if (spriteRect.Left == (currentAnimation.numFrames - 1) * xFrameSize) spriteRect.Left = 0;
                    else spriteRect.Left += xFrameSize;
                }
                animationClock.Restart();
                sprite.TextureRect = spriteRect;                
    
            }

            
        }
        public void Draw(RenderWindow window)
        {
            window.Draw(rec);
            window.Draw(sprite);
        }
    }
}

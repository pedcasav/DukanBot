﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HunterGame.Entidades;

namespace HunterGame.Mecanicas
{
    public enum CharacterState
    {
        None,
        MovingUp,
        MovingLeft,
        MovingDown,
        MovingRight,
        Attack
    }
    abstract class AnimatedCharacter
    {
        public float Xpos { get; set; }
        public float Ypos { get; set; }
        public int map { get; set; }
        private Sprite sprite;
        private IntRect spriteRect;
        private int xFrameSize;
        private int yFrameSize;
        public CharacterState CurrentState { get; set; }

        protected Animation Anim_Up;
        protected Animation Anim_Left;
        protected Animation Anim_Down;
        protected Animation Anim_Right;

        private Clock animationClock;
        protected float moveSpeed = 50;
        protected float animationSpeed = 0.1f;


        //Barra de vida
        Shape rec;
        private int VidaTotal;
        private int vidaActual;

        public AnimatedCharacter(string filename,int mapa, float Xpos, float Ypos,int vida)
        {
            
            Texture texture = new Texture(filename);
            xFrameSize = (int)texture.Size.X / 4;
            yFrameSize = (int)texture.Size.Y / 4;
            spriteRect = new IntRect(0, 0, xFrameSize,yFrameSize);
            rec = new RectangleShape(new Vector2f(xFrameSize, 10));
            sprite = new Sprite(texture, spriteRect);
            this.Xpos = Xpos;
            this.Ypos = Ypos;
            VidaTotal = vida;
            vidaActual = VidaTotal;
            Anim_Down = new Animation(0, 0, 4);
            Anim_Left = new Animation((int)texture.Size.Y / 4, 0, 4);
            Anim_Right = new Animation((int)texture.Size.Y * 2 / 4, 0, 4);
            Anim_Up = new Animation((int)texture.Size.Y * 3 / 4, 0, 4);
            this.map = mapa;
            animationClock = new Clock();
            rec.FillColor = Color.Red;
            rec.Position = new Vector2f(Xpos, Ypos - 10);
            
        }

        public virtual void Update(float deltaTime)
        {
            Animation currentAnimation = null;
            switch (CurrentState)
            {
                case CharacterState.MovingUp:
                    if (Ypos < -16) return;                    
                    currentAnimation = Anim_Up;
                    
                    Ypos -= moveSpeed * deltaTime;
                    break;
                case CharacterState.MovingLeft:
                    if (Xpos <= 0) return;                    
                    currentAnimation = Anim_Left;

                    if (checkMap(((int)(Xpos) / 32) - 1, (int)(Ypos) / 32)) break;
                    Xpos -= moveSpeed * deltaTime;
                    break;
                case CharacterState.MovingDown:
                    currentAnimation = Anim_Down;
                    if (checkMap((int)(Xpos) / 32, (int)(Ypos) / 32 + 1)) break;
                    Ypos += moveSpeed * deltaTime;                    
                    break;
                case CharacterState.MovingRight:
                    currentAnimation = Anim_Right;
                    if (checkMap(((int)(Xpos) / 32) + 1, (int)(Ypos) / 32)) break;
                    Xpos += moveSpeed * deltaTime;
                    break;
                case CharacterState.Attack:
                    vidaActual--;
                    rec = new RectangleShape(new Vector2f(xFrameSize * vidaActual / VidaTotal, 10));
                    break;
            }
            sprite.Position = new Vector2f(Xpos, Ypos);
            rec.Position = new Vector2f(Xpos, Ypos - 10);
            if (animationClock.ElapsedTime.AsSeconds() > animationSpeed)
            {
                if (currentAnimation != null)
                {
                    spriteRect.Top = currentAnimation.offsetTop;
                    if (spriteRect.Left == (currentAnimation.numFrames - 1) * xFrameSize) spriteRect.Left = 0;
                    else spriteRect.Left += xFrameSize;
                }
                animationClock.Restart();
                sprite.TextureRect = spriteRect;                
    
            }

            
        }
        private bool checkMap(int Xpos, int Ypos)
        {
            if (Xpos < 0 || Ypos < 0) return false;
            AtributosMapa att = Global.Mapas[map].atributos[Xpos, Ypos];
            if (att.id == 1)
                return true;
            else if (att.id == 2)
            {
                map = att.value2;
                Xpos = att.value3;
                Ypos = att.value4;
                return true;
            }
            return false;

        }
        public void Draw(RenderWindow window)
        {
            window.Draw(rec);
            window.Draw(sprite);
        }
    }
}

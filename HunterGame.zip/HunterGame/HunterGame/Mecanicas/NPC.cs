﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace HunterGame.Mecanicas
{
    class NPC : AnimatedCharacter
    {
        public NPC(float xpos,float ypos,int vida) : base(Application.StartupPath + @"\thelegal.png",xpos,ypos,vida)
        {
        }
    }
}

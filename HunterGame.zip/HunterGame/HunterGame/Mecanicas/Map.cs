﻿using SFML.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HunterGame.Mecanicas
{
    class Map
    {
        public string url { get; set; }
        //image size
        Sprite sprite;
        public Map(string url)
        {
            try
            {
                this.url = url;
                //Load Source
                Texture texture = new Texture(Application.StartupPath + @"\map\"+ this.url +".png");
                sprite = new Sprite(texture, new IntRect(0, 0, (int)texture.Size.X, (int)texture.Size.Y));
            }
            catch (Exception ex)
            {
            }


        }
        public void Draw(RenderWindow window)
        {
            try
            {
                
                window.Draw(sprite);
            }
            catch (Exception ex)
            {
            }
        }
    }
}
